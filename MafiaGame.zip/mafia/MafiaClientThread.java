package sist.com.mafia;

import javax.swing.ImageIcon;

public class MafiaClientThread extends Thread {

	private MafiaClient clientChat;
	private String message;
	ImageIcon mafiaIcon = new ImageIcon("e:\\mf\\mafia.jpg");
	ImageIcon deadmafiaIcon = new ImageIcon("e:\\mf\\deadmafia.jpg");
	ImageIcon deadcitizenIcon = new ImageIcon("e:\\mf\\deadcitizen.jpg");
	ImageIcon ouser = new ImageIcon("e:\\mf\\2.jpg");

	public MafiaClientThread(MafiaClient clientChat) {
		// TODO Auto-generated constructor stub
		this.clientChat = clientChat;
	}

	public void reset() {
		clientChat.setState(0); // �ƿ� �ʱ�ȭ
		clientChat.setJob(0); // ���� �ʱ�ȭ
		clientChat.setgTime(0);
		clientChat.getJbtn().setEnabled(true);
		clientChat.getJtf().setEnabled(true);
		clientChat.setOutList();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		boolean isStop = false;
		while (!isStop) {
			try {

				message = (String) clientChat.getOis().readObject();

				if (message.equals("[mafia]")) {
					clientChat.setJob(1);
					clientChat.getJl2().setIcon(mafiaIcon);
				}

				if (message.startsWith("[START]")) {
					clientChat.getJta().append("Game Start!" + "\r\n");
					for (int i = 0; i < 6; i++) {
						clientChat.getLlist().get(i).setText(message.split("%")[i + 1]);
						clientChat.getBlist().get(i).setEnabled(false);
					}
					clientChat.day();
					System.out.println("New Round");
				}

				if (message.startsWith("[MAFIAWIN]")) {
					reset();
					// ���Ǿ� �� ���̾�α�
					clientChat.mafiaWin();
					clientChat.getJta().append("���Ǿ� ��" + "\r\n");
				}

				if (message.startsWith("[CIVILWIN]")) {
					reset();
					// �ù� �� ���̾�α�
					clientChat.civilWin();
					clientChat.getJta().append("�ù� ��" + "\r\n");
				}

				if (message.startsWith("[OUT]")) {
					clientChat.setState(1);
					if (clientChat.getJob() == 1) {
						clientChat.getJl2().setIcon(deadmafiaIcon);
					} else {
						clientChat.getJl2().setIcon(deadcitizenIcon);
					}
					if (clientChat.getgTime() == 1) {
						clientChat.death();
					} else {
						clientChat.arrested();
					}
				}

				if (message.startsWith("[EXCEPT]")) {
					clientChat.setOutList(message.split("]")[1]);
				}

				if (message.startsWith("[TIME]")) {
					clientChat.getJl1().setText(message.split("]")[1] + " sec");
				}

				if (message.startsWith("[SERVER]")) {
					clientChat.getJta().append(message);
					clientChat.getJta().setCaretPosition(clientChat.getJta().getDocument().getLength());
				}

				if (message.startsWith("[VOTINGSTART]")) {
					clientChat.getJl1().setText("");

					if (clientChat.getgTime() == 0) {
						for (int i = 0; i < clientChat.getBlist().size(); i++) {
							clientChat.getBlist().get(i).setEnabled(true);
						}
						if (!clientChat.getOutList().equals("")) {
							for (int i = 0; i < clientChat.getOutList().split("%").length; i++) {
								clientChat.getBlist().get(Integer.parseInt(clientChat.getOutList().split("%")[i]))
										.setEnabled(false);
							}
						}
					} else {
						if (clientChat.getJob() == 1) {
							for (int i = 0; i < clientChat.getBlist().size(); i++) {
								clientChat.getBlist().get(i).setEnabled(true);
							}
							if (!clientChat.getOutList().equals("")) {
								for (int i = 0; i < clientChat.getOutList().split("%").length; i++) {
									clientChat.getBlist().get(Integer.parseInt(clientChat.getOutList().split("%")[i]))
											.setEnabled(false);
								}
							}
						}
					}
					clientChat.getJtf().setEnabled(false);
					clientChat.getJta().append("[SERVER] ��ǥ�ϼ���" + "\r\n");
					clientChat.getJta().setCaretPosition(clientChat.getJta().getDocument().getLength());
				}

				if (message.startsWith("[VOTINGEND]")) {
					if (!clientChat.getOutList().equals("")) {
						for (int i = 0; i < clientChat.getOutList().split("%").length; i++) {
							clientChat.getBlist().get(Integer.parseInt(clientChat.getOutList().split("%")[i]))
									.setDisabledIcon(ouser);
						}
					}
					if (clientChat.getgTime() == 0) {
						clientChat.night();
						clientChat.setgTime(1);
						clientChat.getJtf().setEnabled(true);
					} else {
						clientChat.day();
						clientChat.setgTime(0);
						clientChat.getJtf().setEnabled(true);

					}
				}

				if (message.contains("#")) {
					String[] str = message.split("#");

					if (str[1].equals("exit")) {
						if (str[0].equals(clientChat.getId())) {
							System.exit(0);
						} else {
							clientChat.getJta().append(str[0] + "�� �����ϼ̽��ϴ�.\r\n");
							clientChat.getJta().setCaretPosition(clientChat.getJta().getDocument().getLength());
						}
					} // �����

					if (clientChat.getgTime() == 0) {
						clientChat.getJta().append(str[0] + " : " + str[1] + "\r\n");
						clientChat.getJta().setCaretPosition(clientChat.getJta().getDocument().getLength());
					} else {
						if (str[2].equals("1")) {
							if (clientChat.getJob() == 1) {
								clientChat.getJta().append(str[0] + " : " + str[1] + "\r\n");
								clientChat.getJta().setCaretPosition(clientChat.getJta().getDocument().getLength());
							}
						}
					}
				}

			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				isStop = true;
			}
		}
	}
}
package sist.com.mafia;

import java.awt.Color;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

public class HtpDialog extends Dialog implements ActionListener {

	Dimension dimension = getToolkit().getDefaultToolkit().getScreenSize();
	ImageIcon img = new ImageIcon("C:\\work\\JavaStart\\src\\sist\\com\\mafia\\mf\\mafiaRule.jpg");
	JButton jbtn = new JButton("Okay");

	public HtpDialog(MafiaLogin login) {
		super(login);

		JPanel background = new JPanel(null) {
			public void paintComponent(Graphics g) {
				g.drawImage(img.getImage(), 0, 0, HtpDialog.this);
				setOpaque(false);
				super.paintComponents(g);
			}
		};

		this.add(background);
		background.add(jbtn);
		jbtn.setFont(new Font("Bradley Hand ITC", Font.BOLD, 35));
		jbtn.setBounds(300, 550, 200, 40);
		jbtn.setBackground(Color.black);
		jbtn.setForeground(Color.WHITE);
		jbtn.addActionListener(this);

		this.setBounds((dimension.width - 1000) / 2, (dimension.height - 650) / 2, 1000, 650);
		this.setVisible(true);
		this.setResizable(false);
		this.setTitle("How To Play");

		this.addWindowListener(new WindowAdapter() {

			@Override
			public void windowClosing(WindowEvent e) {
				// TODO Auto-generated method stub
				HtpDialog.this.dispose();
			}
		});
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == jbtn) {
			HtpDialog.this.dispose();
		}
	}
}

package sist.com.mafia;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Timer;
import java.util.TimerTask;

public class AppServerThread extends Thread {

	private AppServer server;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	private Socket socket;
	private final int NIGHTTIME = 30;
	private final int DAYTIME = 60;
	private int i; // timer sec
	private int topSelected = 6;

	public AppServerThread(AppServer server) {
		super();
		this.server = server;
	}

	public void broadCastJob() {
		try {
			oos.writeObject("[mafia]"); // ���Ǿƿ��Ը� ������ ����
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void broadCastOut() {
		try {
			oos.writeObject("[OUT]"); // �װų� ü��
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void broadCast(String message) {
		for (AppServerThread a : server.getList()) {
			a.sendMessage(message);
		}
	}

	public void sendMessage(String message) {
		try {
			oos.writeObject(message);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public boolean winCheck() {
		return (server.getCivil() == server.getMafia()) || (server.getMafia() == 0) ? true : false;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

		boolean isStop = false;
		try {
			socket = server.getSocket();
			ois = new ObjectInputStream(socket.getInputStream());
			oos = new ObjectOutputStream(socket.getOutputStream());
			String message = null;

			while (!isStop) {
				message = (String) ois.readObject(); // write �ϱ� ������ read�� ���

				if (message.startsWith("[ID]")) {
					server.setNames(message.split("%")[1]);
				}

				if (message.startsWith("[READY]")) {
					server.setReady(1);
				}

				if (server.getReady() == 6) {
					broadCast("[START]" + server.getNames());
					server.gamestart();
				}

				if (message.startsWith("[VOTE]")) {

					if (message.split("]")[1].equals("0") || message.split("]")[1].equals("1")
							|| message.split("]")[1].equals("2") || message.split("]")[1].equals("3")
							|| message.split("]")[1].equals("4") || message.split("]")[1].equals("5")) {

						server.setCount(1); // ��ǥ �ο� ���

						if (message.split("]")[1].equals("0")) {
							server.setUser0();
						}
						if (message.split("]")[1].equals("1")) {
							server.setUser1();
						}
						if (message.split("]")[1].equals("2")) {
							server.setUser2();
						}
						if (message.split("]")[1].equals("3")) {
							server.setUser3();
						}
						if (message.split("]")[1].equals("4")) {
							server.setUser4();
						}
						if (message.split("]")[1].equals("5")) {
							server.setUser5();
						}

						if (server.getgTime() == 1) { // ���� ��
							if (server.getCount() == server.getMafia()) {
								int[] m = { server.getUser0(), server.getUser1(), server.getUser2(), server.getUser3(),
										server.getUser4(), server.getUser5(), 0 };
								for (int i = 0; i < m.length; i++) {
									if (m[i] > m[topSelected]) {
										topSelected = i;
									}
								}
								System.out.println("count top " + m[topSelected] + " [" + topSelected + "]");

								for (int i = 0; i < m.length; i++) {
									if (m[topSelected] == m[i] && topSelected != i) {
										broadCast("[SERVER] ��ǥ ���� ������ ��ȿ�Դϴ�.");
										topSelected = 6;
										break;
									}
								}

								if (topSelected != 6) {
									if (topSelected == server.getMafia1User()
											|| topSelected == server.getMafia2User()) {
										broadCast("[SERVER] " + server.getNames().split("%")[topSelected + 1]
												+ " ���� ���� ���߽��ϴ�.\r\n");
										server.setMafia();
										server.getList().get(topSelected).broadCastOut();
										broadCast("[EXCEPT]" + topSelected);
									} else {
										broadCast("[SERVER] ������ �ù� " + server.getNames().split("%")[topSelected + 1]
												+ " ���� ���� ���߽��ϴ�.\r\n");
										server.setCivil();
										server.getList().get(topSelected).broadCastOut();
										broadCast("[EXCEPT]" + topSelected);
									}
								}

								server.resetUser();
								server.setCount(0);

								if (winCheck()) {
									if (server.getMafia() == 0) {
										server.setCivil(server.CIVIL_COUNT);
										server.setMafia(server.MAFIA_COUNT);
										broadCast("[CIVILWIN]");
									} else {

										server.setCivil(server.CIVIL_COUNT);
										server.setMafia(server.MAFIA_COUNT);
										broadCast("[MAFIAWIN]");

									}
								} else {
									broadCast("[VOTINGEND]");
								}
							}
						} else { // ���� ��

							if (server.getCount() == server.getRemainMember()) {
								int[] m = { server.getUser0(), server.getUser1(), server.getUser2(), server.getUser3(),
										server.getUser4(), server.getUser5(), 0 };
								for (int i = 0; i < m.length; i++) {
									if (m[i] > m[topSelected]) {
										topSelected = i;
									}
								}
								System.out.println("count top " + m[topSelected] + " [" + topSelected + "]");

								for (int i = 0; i < m.length; i++) {
									if (m[topSelected] == m[i] && topSelected != i) {
										broadCast("[SERVER] ��ǥ ���� ������ ��ȿ�Դϴ�.\r\n");
										topSelected = 6;
										break;
									}
								}

								if (topSelected != 6) {
									if (topSelected == server.getMafia1User()
											|| topSelected == server.getMafia2User()) {
										broadCast("[SERVER] ������ ���Ǿ� " + server.getNames().split("%")[topSelected + 1]
												+ " ���� ü���Ǿ����ϴ�.\r\n");
										server.setMafia();
										server.getList().get(topSelected).broadCastOut();
										broadCast("[EXCEPT]" + topSelected);
									} else {
										broadCast("[SERVER] ������ �ù� " + server.getNames().split("%")[topSelected + 1]
												+ " ���� ü���Ǿ����ϴ�.\r\n");
										server.setCivil();
										server.getList().get(topSelected).broadCastOut();
										broadCast("[EXCEPT]" + topSelected);
									}
								}

								server.resetUser();
								server.setCount(0);

								if (winCheck()) {
									if (server.getMafia() == 0) {
										server.setCivil(server.CIVIL_COUNT);
										server.setMafia(server.MAFIA_COUNT);
										broadCast("[CIVILWIN]");
									} else {
										server.setCivil(server.CIVIL_COUNT);
										server.setMafia(server.MAFIA_COUNT);
										broadCast("[MAFIAWIN]");
									}
								} else {
									broadCast("[VOTINGEND]");
								}
							}
						}
					}
				}

				if (message.startsWith("[DAY]")) {
					server.setgTime(0);
					i = DAYTIME;
					server.setCount(1);
					if (server.getCount() == 6) {
						Timer t = new Timer();
						TimerTask tt = new TimerTask() {

							@Override
							public void run() {
								// TODO Auto-generated method stub
								broadCast("[TIME]" + i);
								if (i < 0) {
									t.cancel();
									broadCast("[SERVER] " + "���� �������ϴ�." + "\r\n");
									broadCast("[VOTINGSTART]");
									server.setCount(0);
									i = NIGHTTIME;
									return;
								}

								if (i == DAYTIME) {
									broadCast("[SERVER] " + "�� �Դϴ�." + "\r\n");
									broadCast("[SERVER] " + i + " �� ���ҽ��ϴ�." + "\r\n");
									i = i - 1;
								} else if (i <= 5) {
									broadCast("[SERVER] " + i + " �� ���ҽ��ϴ�." + "\r\n");
									i = i - 1;
								} else {
									i = i - 1;
								}
							}
						};
						t.schedule(tt, 0, 1000);
					}
				}

				if (message.startsWith("[NIGHT]")) {
					server.setgTime(1);
					i = NIGHTTIME;
					server.setCount(1);
					if (server.getCount() == 6) {
						Timer t = new Timer();
						TimerTask tt = new TimerTask() {

							@Override
							public void run() {
								// TODO Auto-generated method stub
								broadCast("[TIME]" + i);
								if (i < 0) {
									t.cancel();
									broadCast("[SERVER] " + "���� �������ϴ�." + "\r\n");
									broadCast("[VOTINGSTART]");
									server.setCount(0);
									i = DAYTIME;
									return;
								}

								if (i == NIGHTTIME) {
									broadCast("[SERVER] " + "�� �Դϴ�." + "\r\n");
									broadCast("[SERVER] " + i + " �� ���ҽ��ϴ�." + "\r\n");
									i = i - 1;
								} else if (i <= 5) {
									broadCast("[SERVER] " + i + " �� ���ҽ��ϴ�." + "\r\n");
									i = i - 1;
								} else {
									i = i - 1;
								}
							}
						};
						t.schedule(tt, 0, 1000);
					}
				}

				if (message.contains("#")) {
					broadCast(message);
				}
			} // while

			server.getList().remove(this);
			System.out.println(socket.getInetAddress() + "�� ����");
			System.out.println("���������ڼ���:" + server.getList().size() + "��");

		} catch (

		Exception e) {
			// TODO: handle exception
			server.getList().remove(this);
			System.out.println(socket.getInetAddress() + "�� ����");
			System.out.println("���������ڼ���:" + server.getList().size() + "��");
		}
	}
}

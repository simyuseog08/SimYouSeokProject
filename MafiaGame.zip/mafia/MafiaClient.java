package sist.com.mafia;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

public class MafiaClient extends Frame implements ActionListener {

	Dimension dimension = getToolkit().getDefaultToolkit().getScreenSize();
	ImageIcon citizenIcon = new ImageIcon("e:\\mf\\citizen.jpg");

	ImageIcon user = new ImageIcon("e:\\mf\\1.jpg");
	ImageIcon ouser = new ImageIcon("e:\\mf\\2.jpg");
	ImageIcon voteend = new ImageIcon("e:\\mf\\3.jpg");
	ImageIcon ready = new ImageIcon("e:\\mf\\ready.jpg");
	ImageIcon day = new ImageIcon("e:\\mf\\day.jpg");
	ImageIcon night = new ImageIcon("e:\\mf\\night.jpg");
	ImageIcon img = new ImageIcon("e:\\mf\\background.jpg");

	private JPanel jp1, jp2, jp3, jp4;
	private JTextArea jta;
	private JTextField jtf;
	private JButton jbtn; // ready ��ư
	private ArrayList<JButton> blist = new ArrayList<JButton>();
	private ArrayList<JLabel> llist = new ArrayList<JLabel>();
	private JLabel jl1, jl2;
	private String id;
	private String ip;
	private JScrollPane jsp;
	private String outList = "";

	private int job = 0;
	private int gTime = 0; // day = 0 , night = 1;

	// ======================= ui

	private Socket socket;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;

	private static final int PORT = 5000;

	private int state = 0; // dead = 1 or alive = 0

	public void mafiaWin() { // ���Ǿ� ��
		new GameDialog(this).mafiaWin();
	}

	public void civilWin() { // �ù� ��
		new GameDialog(this).civilWin();
	}

	public void death() { // ��� ��
		new GameDialog(this).death();
	}

	public void arrested() { // �˰� ��
		new GameDialog(this).arrested();
	}

	public JButton getJbtn() {
		return jbtn;
	}

	public void setJbtn(JButton jbtn) {
		this.jbtn = jbtn;
	}

	public String getOutList() {
		return outList;
	}

	public void setOutList(String outList) {
		this.outList += (outList + "%");
	}

	public void setOutList() {
		this.outList = "";
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public JLabel getJl1() {
		return jl1;
	}

	public void setJl1(JLabel jl1) {
		this.jl1 = jl1;
	}

	public JLabel getJl2() {
		return jl2;
	}

	public void setJl2(JLabel jl2) {
		this.jl2 = jl2;
	}

	public ArrayList<JLabel> getLlist() {
		return llist;
	}

	public void setLlist(ArrayList<JLabel> llist) {
		this.llist = llist;
	}

	public int getgTime() {
		return gTime;
	}

	public void setgTime(int gTime) {
		this.gTime = gTime;
	}

	public ArrayList<JButton> getBlist() {
		return blist;
	}

	public void setBlist(ArrayList<JButton> blist) {
		this.blist = blist;
	}

	public int getJob() {
		return job;
	}

	public void setJob(int job) {
		this.job = job;
	}

	public JTextArea getJta() {
		return jta;
	}

	public void setJta(JTextArea jta) {
		this.jta = jta;
	}

	public JTextField getJtf() {
		return jtf;
	}

	public void setJtf(JTextField jtf) {
		this.jtf = jtf;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public Socket getSocket() {
		return socket;
	}

	public void setSocket(Socket socket) {
		this.socket = socket;
	}

	public ObjectInputStream getOis() {
		return ois;
	}

	public void setOis(ObjectInputStream ois) {
		this.ois = ois;
	}

	public ObjectOutputStream getOos() {
		return oos;
	}

	public void setOos(ObjectOutputStream oos) {
		this.oos = oos;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

		Object obj = e.getSource();

		try {
			if (obj == jbtn) {
				jbtn.setEnabled(false);
				oos.writeObject("[READY]");
				jl2.setIcon(citizenIcon);
			}

			if (state != 1) {
				if (obj == blist.get(0) || obj == blist.get(1) || obj == blist.get(2) || obj == blist.get(3)
						|| obj == blist.get(4) || obj == blist.get(5)) {

					if (obj == blist.get(0)) {
						oos.writeObject("[VOTE]0");
						for (int i = 0; i < blist.size(); i++) {
							blist.get(i).setEnabled(false);
						}
					}
					if (obj == blist.get(1)) {
						oos.writeObject("[VOTE]1");
						for (int i = 0; i < blist.size(); i++) {
							blist.get(i).setEnabled(false);
						}
					}
					if (obj == blist.get(2)) {
						oos.writeObject("[VOTE]2");
						for (int i = 0; i < blist.size(); i++) {
							blist.get(i).setEnabled(false);
						}
					}
					if (obj == blist.get(3)) {
						oos.writeObject("[VOTE]3");
						for (int i = 0; i < blist.size(); i++) {
							blist.get(i).setEnabled(false);
						}
					}
					if (obj == blist.get(4)) {
						oos.writeObject("[VOTE]4");
						for (int i = 0; i < blist.size(); i++) {
							blist.get(i).setEnabled(false);
						}
					}
					if (obj == blist.get(5)) {
						oos.writeObject("[VOTE]5");
						for (int i = 0; i < blist.size(); i++) {
							blist.get(i).setEnabled(false);
						}
					}

				}

				if (obj == jtf) {
					if (jtf.getText().equals("") || jtf.getText().length() == 0) {
						JOptionPane.showMessageDialog(this, "MessageCheck!");
						return;
					} else {
						oos.writeObject(id + "#" + jtf.getText() + "#" + job);
						jtf.setText("");
						jtf.requestFocus();
					}
				}
			}

		} catch (Exception e2) {
			// TODO: handle exception
			e2.printStackTrace();
		}
	}

	public void day() {
		try {
			oos.writeObject("[DAY]");
			jbtn.setDisabledIcon(day);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void night() {
		try {
			oos.writeObject("[NIGHT]");
			jbtn.setDisabledIcon(night);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void connect() {
		try {
			socket = new Socket(ip, PORT); // socket �� ������ִ� ���� connection �� �̷����
			oos = new ObjectOutputStream(socket.getOutputStream());
			ois = new ObjectInputStream(socket.getInputStream());

			MafiaClientThread ct = new MafiaClientThread(this);
			ct.start();

			oos.writeObject("[ID]" + "%" + id);

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	public void initPro(String id, String ip) {

		this.id = id;
		this.ip = ip;

		JPanel background = new JPanel(null) {
			public void paintComponent(Graphics g) {
				g.drawImage(img.getImage(), 0, 0, MafiaClient.this);
				setOpaque(false);
				super.paintComponents(g);
			}
		};
		this.add(background);

		for (int i = 0; i < 6; i++) {
			blist.add(new JButton());
			llist.add(new JLabel());
		}

		for (int i = 0; i < blist.size(); i++) {
			background.add(blist.get(i));
			background.add(llist.get(i));
			llist.get(i).setForeground(Color.WHITE);
			llist.get(i).setHorizontalAlignment(JLabel.CENTER);
			blist.get(i).addActionListener(this);
			blist.get(i).setIcon(user);
			blist.get(i).setDisabledIcon(voteend);
		}

		background.add(jbtn = new JButton(ready));
		jbtn.setBounds(30, 120, 275, 30);
		jbtn.setBorder(new LineBorder(Color.gray));
		jbtn.setDisabledIcon(day);
		jbtn.addActionListener(this);

		background.add(jl1 = new JLabel(""));
		jl1.setBounds(510, 113, 60, 25);
		jl1.setForeground(Color.white);

		background.add(jsp = new JScrollPane(jta = new JTextArea(), JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_NEVER));
		jsp.setBounds(30, 150, 550, 650);
		jsp.setBorder(new LineBorder(Color.gray));
		jta.setEditable(false);
		jta.setBackground(Color.LIGHT_GRAY);

		background.add(jtf = new JTextField());
		jtf.setBounds(30, 825, 550, 30);
		jtf.addActionListener(this);

		background.add(jl2 = new JLabel(citizenIcon));
		jl2.setBounds(610, 150, 355, 250);
//		jl2.setBorder(new LineBorder(Color.gray));

		blist.get(0).setBounds(615, 440, 160, 90);
		blist.get(0).setBorder(new LineBorder(Color.black));
		llist.get(0).setBounds(610, 535, 170, 30);

		blist.get(1).setBounds(800, 440, 160, 90);
		blist.get(1).setBorder(new LineBorder(Color.black));
		llist.get(1).setBounds(795, 535, 170, 30);

		blist.get(2).setBounds(615, 585, 160, 90);
		blist.get(2).setBorder(new LineBorder(Color.black));
		llist.get(2).setBounds(610, 680, 170, 30);

		blist.get(3).setBounds(800, 585, 160, 90);
		blist.get(3).setBorder(new LineBorder(Color.black));
		llist.get(3).setBounds(795, 680, 170, 30);

		blist.get(4).setBounds(615, 730, 160, 90);
		blist.get(4).setBorder(new LineBorder(Color.black));
		llist.get(4).setBounds(610, 825, 170, 30);

		blist.get(5).setBounds(800, 730, 160, 90);
		blist.get(5).setBorder(new LineBorder(Color.black));
		llist.get(5).setBounds(795, 825, 170, 30);
	}

	public MafiaClient(String id, String ip) {
		initPro(id, ip);
		this.setTitle("MafiaGame");
		this.addWindowListener(new WindowAdapter() {

			@Override
			public void windowClosing(WindowEvent e) {
				// TODO Auto-generated method stub
				System.exit(0);
			}
		});
		this.setBounds((dimension.width - 1000) / 2, (dimension.height - 1000) / 2, 1000, 1000);
		this.setVisible(true);

	}
}

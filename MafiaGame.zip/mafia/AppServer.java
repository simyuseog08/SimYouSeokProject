package sist.com.mafia;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class AppServer {
	static final int PORT = 5000;
	Socket socket;
	ArrayList<AppServerThread> list;

	final int CIVIL_COUNT = 4;
	final int MAFIA_COUNT = 2;

	int civil = CIVIL_COUNT;
	int mafia = MAFIA_COUNT;

	int remainMember = 0;
	int ready = 0;

	int count = 0;
	String names = "%";

	int gTime = 0;

	public int getgTime() {
		return gTime;
	}

	public void setgTime(int gTime) {
		this.gTime = gTime;
	}

	int mafia1User = -1;
	int mafia2User = -1;

	public int getMafia1User() {
		return mafia1User;
	}

	public void setMafia1User(int mafia1User) {
		this.mafia1User = mafia1User;
	}

	public int getMafia2User() {
		return mafia2User;
	}

	public void setMafia2User(int mafia2User) {
		this.mafia2User = mafia2User;
	}

	// ============== voting ==============

	int user0 = 0;
	int user1 = 0;
	int user2 = 0;
	int user3 = 0;
	int user4 = 0;
	int user5 = 0;

	public int getUser0() {
		return user0;
	}

	public void setUser0() {
		this.user0 += 1;
	}

	public int getUser1() {
		return user1;
	}

	public void setUser1() {
		this.user1 += 1;
	}

	public int getUser2() {
		return user2;
	}

	public void setUser2() {
		this.user2 += 1;
	}

	public int getUser3() {
		return user3;
	}

	public void setUser3() {
		this.user3 += 1;
	}

	public int getUser4() {
		return user4;
	}

	public void setUser4() {
		this.user4 += 1;
	}

	public int getUser5() {
		return user5;
	}

	public void setUser5() {
		this.user5 += 1;
	}

	public int getCivil() {
		return civil;
	}

	public void setCivil() {
		this.civil = this.civil - 1;
	}

	public void setCivil(int civil) {
		this.civil = civil;
	}

	public int getMafia() {
		return mafia;
	}

	public void setMafia() {
		this.mafia = this.mafia - 1;
	}

	public void setMafia(int mafia) {
		this.mafia = mafia;
	}

	public int getRemainMember() {
		return remainMember = civil + mafia;
	}

	// ========================================

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		if (count == 0) {
			this.count = 0;
		} else {
			this.count += count;
		}
	}

	public String getNames() {
		return names;
	}

	public void setNames(String names) {
		this.names += (names + "%");
	}

	public int getReady() {
		return ready;
	}

	public void setReady(int ready) {
		this.ready += ready;
	}

	public Socket getSocket() {
		return socket;
	}

	public void setSocket(Socket socket) {
		this.socket = socket;
	}

	public ArrayList<AppServerThread> getList() {
		return list;
	}

	public void setList(ArrayList<AppServerThread> list) {
		this.list = list;
	}

	public void resetUser() {
		user0 = 0;
		user1 = 0;
		user2 = 0;
		user3 = 0;
		user4 = 0;
		user5 = 0;
	}

	public void gamestart() { //�������� ���ڸ� �̾� �ش� ��ȣ �������� ���Ǿ� ���� �ο�

		int a = (int) (Math.random() * 6);
		int b = (int) (Math.random() * 6);
		while (true) {
			if (a != b)
				break;
			b = (int) (Math.random() * 6);
		}
		ready = 0;
		mafia1User = a;
		mafia2User = b;
		list.get(a).broadCastJob();
		list.get(b).broadCastJob();
	}

	public AppServer() {
		boolean isStop = false;
		System.out.println("Server is Ready!");
		list = new ArrayList<AppServerThread>();
		while (!isStop) {
			try {
				ServerSocket serverSocket = new ServerSocket(PORT); //
				socket = serverSocket.accept(); // 6�� ���� return ���� socket ������ �־��ֱ�
				AppServerThread appServerThread = new AppServerThread(this); // middle ware ����
				appServerThread.start();
				list.add(appServerThread);
				System.out.println("���� ������ �� : " + list.size());
				System.out.println(socket);

			} catch (Exception e) {
				// TODO: handle exception
			}
		}
	}

	public static void main(String[] args) {
		new AppServer();
	}
}

package sist.com.mafia;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class MafiaLogin extends Frame implements ActionListener, MouseListener {

	Dimension dimension = getToolkit().getDefaultToolkit().getScreenSize();
	ImageIcon enter = new ImageIcon("e:\\mf\\enter.jpg");
	ImageIcon hwt = new ImageIcon("e:\\mf\\hwt.jpg");
	ImageIcon img = new ImageIcon("e:\\mf\\main.jpg");
	private JButton jbtn1, jbtn2;
	private JTextField jtf;
	JPanel jPanel = new JPanel();
	JPanel jPanel1 = new JPanel();
	JPanel jPanel2 = new JPanel();
	JPanel jPanel3 = new JPanel();
	JPanel jPanel4 = new JPanel();

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		jtf.setText("");
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

		if (e.getSource() == jbtn1) {
			int len = jtf.getText().length();
			if (len < 2 || len > 12 || jtf.getText().equals("YOUR NAME")) {
				JOptionPane.showMessageDialog(this, "2�� �̻� 12�� ���� �����մϴ�.");
			} else {
				new MafiaClient(jtf.getText(), "211.63.89.224").connect();
				this.dispose();
			}
			jtf.setText("");
		}

		if (e.getSource() == jbtn2) {
			HtpDialog htpDialog = new HtpDialog(this);
		}
	}

	public void loginView() {
		JPanel background = new JPanel(null) {
			public void paintComponent(Graphics g) {
				g.drawImage(img.getImage(), 0, 0, MafiaLogin.this);
				setOpaque(false);
				super.paintComponents(g);
			}
		};

		jbtn1 = new JButton(enter);
		jbtn1.setBounds(520, 550, 150, 40);
		jbtn1.addActionListener(this);

		jbtn2 = new JButton(hwt);
		jbtn2.setBounds(690, 550, 150, 40);
		jbtn2.addActionListener(this);

		jtf = new JTextField(50);
		jtf.setBounds(200, 550, 300, 40);
		jtf.addActionListener(this);
		jtf.addMouseListener(this);
		jtf.setBackground(Color.gray);
		jtf.setForeground(Color.WHITE);
		jtf.setFont(new Font("�޸յձ�������", Font.PLAIN, 20));
		jtf.setHorizontalAlignment(JTextField.CENTER);
		jtf.setText("YOUR NAME");

		background.add(jtf);

		background.add(jbtn1);
		background.add(jbtn2);

		this.add(background);
	}

	public MafiaLogin() {
		loginView();
		this.setTitle("Mafia Login");
		this.setVisible(true);
		this.setLocationRelativeTo(null);
		this.setBounds((dimension.width - 1000) / 2, (dimension.height - 650) / 2, 1000, 650);
		this.setResizable(false);
		this.addWindowListener(new WindowAdapter() {

			@Override
			public void windowClosing(WindowEvent e) {
				// TODO Auto-generated method stub
				super.windowClosing(e);
				System.exit(0);
			}

		});
	}

	public static void main(String[] args) {
		new MafiaLogin();
	}
}

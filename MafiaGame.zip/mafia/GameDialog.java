package sist.com.mafia;

import java.awt.Dialog;
import java.awt.Dimension;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;

public class GameDialog extends Dialog implements ActionListener {

	JButton jbtn = new JButton();
	Dimension dimension = getToolkit().getDefaultToolkit().getScreenSize();
	ImageIcon death = new ImageIcon("e:\\mf\\nightd.JPG");
	ImageIcon arrested = new ImageIcon("e:\\mf\\noond.JPG");
	ImageIcon mafiaWin = new ImageIcon("e:\\mf\\mv.JPG");
	ImageIcon civilWin = new ImageIcon("e:\\mf\\cv.JPG");

	public GameDialog(MafiaClient client) {
		super(client);
	}

	public void mafiaWin() {
		iniDialog();
		this.setBounds((dimension.width - 1000) / 2 + 50, (dimension.height - 650) / 2 + 150, 800, 500);
		jbtn.setIcon(mafiaWin);
		this.add(jbtn);
	}

	public void civilWin() {
		iniDialog();
		this.setBounds((dimension.width - 1000) / 2 + 50, (dimension.height - 650) / 2 + 150, 800, 500);
		jbtn.setIcon(civilWin);
		this.add(jbtn);
	}

	public void death() {
		iniDialog();
		this.setBounds((dimension.width - 1000) / 2 + 50, (dimension.height - 650) / 2 + 250, 400, 300);
		jbtn.setIcon(death);
		this.setAlwaysOnTop(true);
		this.add(jbtn);
	}

	public void arrested() {
		iniDialog();
		this.setBounds((dimension.width - 1000) / 2 + 50, (dimension.height - 650) / 2 + 250, 400, 300);
		jbtn.setIcon(arrested);
		this.setAlwaysOnTop(true);
		this.add(jbtn);
	}

	public void iniDialog() {
		jbtn.addActionListener(this);
		this.setVisible(true);
		this.setResizable(false);
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				// TODO Auto-generated method stub
				GameDialog.this.dispose();
			}
		});
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == jbtn) {
			GameDialog.this.dispose();
		}
	}
}
